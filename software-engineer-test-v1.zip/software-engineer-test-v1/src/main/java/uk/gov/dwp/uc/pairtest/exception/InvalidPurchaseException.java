package uk.gov.dwp.uc.pairtest.exception;

/**
 * Public InvalidPurchaseException class extends RuntimeException and is the specified Throwable for this project
 */
public class InvalidPurchaseException extends RuntimeException {

}
